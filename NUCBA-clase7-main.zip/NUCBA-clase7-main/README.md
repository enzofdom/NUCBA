## Clase 7

En este repositorio se encuentra el código de la clase 7 , En donde se explicará flexbox.
